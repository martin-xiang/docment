/********************************************************************
 *
 * Registers and bit definitions for Maxim Integrated MCU DS4830A.
 *
 * This file supports assembler and 'C' Compiler  for DS4830A
 *
 * Copyright 2012-2013 IAR Systems. All rights reserved.
 *
 * $Revision: 1 $  Initial Version
 *
 * 20-Feb-2013 - SKJ - DS4830A Header file
 ********************************************************************/


#ifndef __IODS4830A
#define __IODS4830A

#ifdef  __IAR_SYSTEMS_ICC__
#ifndef _SYSTEM_BUILD
#pragma system_include
#endif
#endif

#if (((__TID__ >> 8) & 0x7F) != 0x42)     /* 0x42 = 66 dec */
#error iomaxqxx.h file for use with ICCMAXQ/AMAXQ only
#endif


#ifdef __IAR_SYSTEMS_ICC__
#pragma language=extended

#include "iomaxq.h"


/*-------------------------------------------------------------------------*
 *                  Special Function Registers (SFRs)                      *
 *-------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------*
 *                               Module 0                                *
 *-----------------------------------------------------------------------*/

/* Port 2 Output Register */
__no_init volatile __io union
{
  unsigned char PO2;
  struct
  {
    unsigned char PO2_0         : 1;
    unsigned char PO2_1         : 1;
    unsigned char PO2_2         : 1;
    unsigned char PO2_3         : 1;
    unsigned char PO2_4         : 1;
    unsigned char PO2_5         : 1;
    unsigned char PO2_6         : 1;
    unsigned char PO2_7         : 1;
  } PO2_bit;
} @ _M(0,0);

/* Port 1 Output Register */
__no_init volatile __io union
{
  unsigned char PO1;
  struct
  {
    unsigned char PO1_0         : 1;
    unsigned char PO1_1         : 1;
    unsigned char PO1_2         : 1;
    unsigned char PO1_3         : 1;
    unsigned char PO1_4         : 1;
    unsigned char PO1_5         : 1;
    unsigned char PO1_6         : 1;
    unsigned char PO1_7         : 1;
  } PO1_bit;
} @ _M(0,1);

/* Port 0 Output Register */
__no_init volatile __io union
{
  unsigned char PO0;
  struct
  {
    unsigned char PO0_0         : 1;
    unsigned char PO0_1         : 1;
    unsigned char PO0_2         : 1;
    unsigned char PO0_3         : 1;
    unsigned char PO0_4         : 1;
    unsigned char PO0_5         : 1;
    unsigned char PO0_6         : 1;
    unsigned char PO0_7         : 1;
  } PO0_bit;
} @ _M(0,2);

/* External Interrupt Flag 2 Register */
__no_init volatile __io union
{
  unsigned char EIF2;
  struct
  {
    unsigned char IE0            : 1;   /*Interrupt Edge Detect bit*/
    unsigned char IE1            : 1;
    unsigned char IE2            : 1;
    unsigned char IE3            : 1;
    unsigned char IE4            : 1;
    unsigned char IE5            : 1;
    unsigned char IE6            : 1;
    unsigned char IE7            : 1;
  } EIF2_bit;
} @ _M(0,3);

/* External Interrupt Flag 1 Register */
__no_init volatile __io union
{
  unsigned char EIF1;
  struct
  {
    unsigned char IE0            : 1;   /*Interrupt Edge Detect bit*/
    unsigned char IE1            : 1;
    unsigned char IE2            : 1;
    unsigned char IE3            : 1;
    unsigned char IE4            : 1;
    unsigned char IE5            : 1;
    unsigned char IE6            : 1;
    unsigned char IE7            : 1;
  } EIF1_bit;
} @ _M(0,4);

/* External Interrupt Flag 0 Register */
__no_init volatile __io union
{
  unsigned char EIF0;
  struct
  {
    unsigned char IE0            : 1;   /*Interrupt Edge Detect bit*/
    unsigned char IE1            : 1;
    unsigned char IE2            : 1;
    unsigned char IE3            : 1;
    unsigned char IE4            : 1;
    unsigned char IE5            : 1;
    unsigned char IE6            : 1;
    unsigned char IE7            : 1;
  } EIF0_bit;
} @ _M(0,5);

/* General Timer1 Value Register     */
__no_init volatile __io unsigned int GTV1  @ _M(0,6);

/* General Timer1 Control Register */
__no_init volatile __io union
{
  unsigned int GTCN1;
  struct
  {
    unsigned int GTPS           : 3;   /* Timer Clock Prescaler          */
    unsigned int                : 1;   /* Reserved                       */
    unsigned int GTIF           : 1;   /* General Timer Interrupt flag   */
    unsigned int                : 3;   /* Reserved                       */
    unsigned int GTIE           : 1;   /* General Timer Interrupt Enable */
    unsigned int CLK_SEL        : 2;   /* General Timer Clock Select     */
    unsigned int MODE           : 1;   /* Timer Mode                     */
    unsigned int GTR            : 1;   /* Timer Run Control              */
    unsigned int                : 3;   /* Reserved                       */
  } GTCN1_bit;
} @ _M(0,7);

/* Port 2 Input Register */
__no_init volatile __io union
{
  unsigned char PI2;
  struct
  {
    unsigned char PI2_0         : 1;
    unsigned char PI2_1         : 1;
    unsigned char PI2_2         : 1;
    unsigned char PI2_3         : 1;
    unsigned char PI2_4         : 1;
    unsigned char PI2_5         : 1;
    unsigned char PI2_6         : 1;
    unsigned char PI2_7         : 1;
  } PI2_bit;
} @ _M(0,8);

/* Port 1 Input Register */
__no_init volatile __io union
{
  unsigned char PI1;
  struct
  {
    unsigned char PI1_0         : 1;
    unsigned char PI1_1         : 1;
    unsigned char PI1_2         : 1;
    unsigned char PI1_3         : 1;
    unsigned char PI1_4         : 1;
    unsigned char PI1_5         : 1;
    unsigned char PI1_6         : 1;
    unsigned char PI1_7         : 1;
  } PI1_bit;
} @ _M(0,9);

/* Port 0 Input Register */
__no_init volatile __io union
{
  unsigned char PI0;
  struct
  {
    unsigned char PI0_0         : 1;
    unsigned char PI0_1         : 1;
    unsigned char PI0_2         : 1;
    unsigned char PI0_3         : 1;
    unsigned char PI0_4         : 1;
    unsigned char PI0_5         : 1;
    unsigned char PI0_6         : 1;
    unsigned char PI0_7         : 1;
  } PI0_bit;
} @ _M(0,10);

/* General Timer1 Compare Register */
__no_init volatile __io unsigned int GTC1  @ _M(0,11);

/* External Interrupt Enable 2 Register */
__no_init volatile __io union
{
  unsigned char EIE2;
  struct
  {
    unsigned char EX0            : 1;
    unsigned char EX1            : 1;
    unsigned char EX2            : 1;
    unsigned char EX3            : 1;
    unsigned char EX4            : 1;
    unsigned char EX5            : 1;
    unsigned char EX6            : 1;
    unsigned char EX7            : 1;
  } EIE2_bit;
} @ _M(0,13);

/* External Interrupt Enable 1 Register */
__no_init volatile __io union
{
  unsigned char EIE1;
  struct
  {
    unsigned char EX0            : 1;
    unsigned char EX1            : 1;
    unsigned char EX2            : 1;
    unsigned char EX3            : 1;
    unsigned char EX4            : 1;
    unsigned char EX5            : 1;
    unsigned char EX6            : 1;
    unsigned char EX7            : 1;
  } EIE1_bit;
} @ _M(0,14);

/* External Interrupt Enable 0 Register */
__no_init volatile __io union
{
  unsigned char EIE0;
  struct
  {
    unsigned char EX0            : 1;
    unsigned char EX1            : 1;
    unsigned char EX2            : 1;
    unsigned char EX3            : 1;
    unsigned char EX4            : 1;
    unsigned char EX5            : 1;
    unsigned char EX6            : 1;
    unsigned char EX7            : 1;
  } EIE0_bit;
} @ _M(0,15);

/* Port 2 Direction Register */
__no_init volatile __io union
{
  unsigned char PD2;
  struct
  {
    unsigned char PD2_0         : 1;
    unsigned char PD2_1         : 1;
    unsigned char PD2_2         : 1;
    unsigned char PD2_3         : 1;
    unsigned char PD2_4         : 1;
    unsigned char PD2_5         : 1;
    unsigned char PD2_6         : 1;
    unsigned char PD2_7         : 1;
  } PD2_bit;
} @ _M(0,16);

/* Port 1 Direction Register */
__no_init volatile __io union
{
  unsigned char PD1;
  struct
  {
    unsigned char PD1_0         : 1;
    unsigned char PD1_1         : 1;
    unsigned char PD1_2         : 1;
    unsigned char PD1_3         : 1;
    unsigned char PD1_4         : 1;
    unsigned char PD1_5         : 1;
    unsigned char PD1_6         : 1;
    unsigned char PD1_7         : 1;
  } PD1_bit;
} @ _M(0,17);

/* Port 0 Direction Register */
__no_init volatile __io union
{
  unsigned char PD0;
  struct
  {
    unsigned char PD0_0         : 1;
    unsigned char PD0_1         : 1;
    unsigned char PD0_2         : 1;
    unsigned char PD0_3         : 1;
    unsigned char PD0_4         : 1;
    unsigned char PD0_5         : 1;
    unsigned char PD0_6         : 1;
    unsigned char PD0_7         : 1;
  } PD0_bit;
} @ _M(0,18);

/* External Interrupt Edge Select 2 Register */
__no_init volatile __io union
{
  unsigned char EIES2;
  struct
  {
    unsigned char IT0            : 1;
    unsigned char IT1            : 1;
    unsigned char IT2            : 1;
    unsigned char IT3            : 1;
    unsigned char IT4            : 1;
    unsigned char IT5            : 1;
    unsigned char IT6            : 1;
    unsigned char IT7            : 1;
  } EIES2_bit;
} @ _M(0,19);

/* External Interrupt Edge Select 1 Register */
__no_init volatile __io union
{
  unsigned char EIES1;
  struct
  {
    unsigned char IT0            : 1;
    unsigned char IT1            : 1;
    unsigned char IT2            : 1;
    unsigned char IT3            : 1;
    unsigned char IT4            : 1;
    unsigned char IT5            : 1;
    unsigned char IT6            : 1;
    unsigned char IT7            : 1;
  } EIES1_bit;
} @ _M(0,20);

/* External Interrupt Edge Select 0 Register */
__no_init volatile __io union
{
  unsigned char EIES0;
  struct
  {
    unsigned char IT0            : 1;
    unsigned char IT1            : 1;
    unsigned char IT2            : 1;
    unsigned char IT3            : 1;
    unsigned char IT4            : 1;
    unsigned char IT5            : 1;
    unsigned char IT6            : 1;
    unsigned char IT7            : 1;
  } EIES0_bit;
} @ _M(0,21);

/*-----------------------------------------------------------------------*
 *                               Module 1                                *
 *-----------------------------------------------------------------------*/

//Note: I2CBUF_M is defined as unsigned int for faster code execution.
/* I2C_M Data Buffer */
__no_init volatile __io unsigned int I2CBUF_M @ _M(1,0);

/* I2C_M Status Register */
__no_init volatile __io union
{
  unsigned int I2CST_M;
  struct
  {
    unsigned int I2CSRI         : 1;
    unsigned int I2CTXI         : 1;
    unsigned int I2CRXI         : 1;
    unsigned int I2CSTRI        : 1;
    unsigned int I2CTOI         : 1;
    unsigned int I2CAMI         : 1;
    unsigned int                : 1;
    unsigned int I2CNACKI       : 1;
    unsigned int I2CGCI         : 1;
    unsigned int I2CROI         : 1;
    unsigned int I2CSCL         : 1;
    unsigned int I2CSPI         : 1;
    unsigned int I2CAMI2        : 1;
    unsigned int                : 1;
    unsigned int I2CBUSY        : 1;
    unsigned int I2CBUS         : 1;
  } I2CST_M_bit;
} @ _M(1,1);

/* I2C_M Interrupt Enable Register */
__no_init volatile __io union
{
  unsigned int I2CIE_M;
  struct
  {
    unsigned int I2CSRIE        : 1;
    unsigned int I2CTXIE        : 1;
    unsigned int I2CRXIE        : 1;
    unsigned int I2CSTRIE       : 1;
    unsigned int I2CTOIE        : 1;
    unsigned int I2CAMIE        : 1;
    unsigned int                : 1;
    unsigned int I2CNACKIE      : 1;
    unsigned int I2CGCIE        : 1;
    unsigned int I2CROIE        : 1;
    unsigned int I2CAMI2E       : 1;
    unsigned int I2CSPIE        : 1;
    unsigned int                : 4;
  } I2CIE_M_bit;
} @ _M(1,2);

/* Port 6 Output Register */
__no_init volatile __io union
{
  unsigned char PO6;
  struct
  {
    unsigned char PO6_0          : 1;
    unsigned char PO6_1          : 1;
    unsigned char PO6_2          : 1;
    unsigned char PO6_3          : 1;
    unsigned char PO6_4          : 1;
    unsigned char PO6_5          : 1;
    unsigned char PO6_6          : 1;
    unsigned char                : 1;       /* Reserved; P6_7 is not available in DS4830A */
  } PO6_bit;
} @ _M(1,3);

//New- CRC8 Input Data Register
__no_init volatile __io unsigned char CRC8IN @ _M(1,4);

/* Module1 Interrupt Register */
__no_init volatile __io union
{
  unsigned int MIIR1;
  struct
  {
    unsigned int P6_0         	 : 1;
    unsigned int P6_1         	 : 1;
    unsigned int P6_2         	 : 1;
    unsigned int P6_3         	 : 1;
    unsigned int P6_4         	 : 1;
    unsigned int P6_5         	 : 1;
    unsigned int P6_6         	 : 1;
    unsigned int SVM   	 	     : 1;   /* SVM Module Interrupt                            */
    unsigned int I2CM         	 : 1;   /* I2C Master Module Interrupt                     */
    unsigned int	      	     : 7;
  } MIIR1_bit;
} @ _M(1,5);

/* External Interrupt Flag 6 Register */
__no_init volatile __io union
{
  unsigned char EIF6;
  struct
  {
    unsigned char IE0           : 1;
    unsigned char IE1           : 1;
    unsigned char IE2           : 1;
    unsigned char IE3           : 1;
    unsigned char IE4           : 1;
    unsigned char IE5           : 1;
    unsigned char IE6           : 1;
    unsigned char               : 1;       /* Reserved; P6_7 is not available in DS4830A */
  } EIF6_bit;
}@ _M(1,6);

/* External Interrupt Enable 6 Register  */
__no_init volatile __io union
{
  unsigned char EIE6;
  struct
  {
    unsigned char EX0           : 1;
    unsigned char EX1           : 1;
    unsigned char EX2           : 1;
    unsigned char EX3           : 1;
    unsigned char EX4		    : 1;
    unsigned char EX5           : 1;
    unsigned char EX6           : 1;
    unsigned char               : 1;       /* Reserved; P6_7 is not available in DS4830A */
  } EIE6_bit;
} @ _M(1,7);

/* Port 6 Input Register */
__no_init volatile __io union
{
  unsigned char PI6;
  struct
  {
    unsigned char PI6_0          : 1;
    unsigned char PI6_1          : 1;
    unsigned char PI6_2          : 1;
    unsigned char PI6_3          : 1;
    unsigned char PI6_4          : 1;
    unsigned char PI6_5          : 1;
    unsigned char PI6_6          : 1;
    unsigned char                : 1;       /* Reserved; P6_7 is not available in DS4830 */
  } PI6_bit;
} @ _M(1,8);

/* Supply Voltage Monitor Register */
__no_init volatile __io union
{
  unsigned int SVM;
  struct
  {
    unsigned int SVMEN          : 1;       /* SVM Enable                          */
    unsigned int SVMRDY         : 1;       /* SVM Ready (Read Only)               */
    unsigned int SVMIE          : 1;       /* SVM Interrupt Enable                */
    unsigned int SVMI           : 1;       /* SVM Interrupt Flag                  */
    unsigned int 		: 4;       /* Reserved                            */
    unsigned int SVTH           : 4;       /* Supply Voltage Threshold Bits       */
    unsigned int 	        : 4;       /* Reserved                            */
  } SVM_bit;
} @ _M(1,9);

/* I2C_M Control Register                                                          */
__no_init volatile __io union
{
  unsigned int I2CCN_M;
  struct
  {
    unsigned int I2CEN          : 1;       /* I2C Enable                           */
    unsigned int I2CMST         : 1;       /* I2C Master Mode Enable               */
    unsigned int                : 1;       /*                                      */
    unsigned int                : 1;       /*                                      */
    unsigned int I2CSTRS        : 1;       /* I2C Clock Stretch Select             */
    unsigned int I2CACK         : 1;       /* I2C Data Acknowledge Bit             */
    unsigned int I2CSTART       : 1;       /* I2C START Enable                     */
    unsigned int I2CSTOP        : 1;       /* I2C START Enable                     */
    unsigned int I2CGCEN        : 1;       /* I2C General Call Enable TODO         */
    unsigned int I2CSTREN       : 1;       /* I2C Clock Stretch Enable             */
    unsigned int SMB_MOD        : 1;       /* I2C SMBUS Timerout Enable            */
    unsigned int ADD2EN         : 1;       /* I2C Slave Address 2 Enable (in Slave mode)*/
    unsigned int I2CM_ALT       : 1;       /* I2C Master ALT location Enable       */
    unsigned int                : 2;       /* Reserved                             */
    unsigned int                : 1;       /*                                      */
  } I2CCN_M_bit;
} @ _M(1,12);

/* I2C_M Clock Register */
__no_init volatile __io union
{
  unsigned int I2CCK_M;
  struct
  {
    unsigned int I2CCKL         : 8;       /* I2C Clock Low Bits                   */
    unsigned int I2CCKH         : 8;       /* I2C Clock High Bits                  */
  } I2CCK_M_bit;
} @ _M(1,13);

/* I2C_M Timeout Register       */
__no_init volatile __io unsigned char I2CTO_M  @ _M(1,14);

/* I2C_M Slave Address Register */
__no_init volatile __io union
{
  unsigned int I2CSLA_M;
  struct
  {
    unsigned int I2CMODE         : 1;      /* I2C Master Read and Write mode       */
    unsigned int SLAVE_ADDRESS   : 7;      /* Address of Slave device (7 bit)      */
    unsigned int                 : 8;      /* Reserved*/
  } I2CSLA_M_bit;
} @ _M(1,15);

/* External Interrupt Edge Select 6 Register */
__no_init volatile __io union
{
  unsigned char EIES6;
  struct
  {
    unsigned char IT0           : 1;
    unsigned char IT1           : 1;
    unsigned char IT2           : 1;
    unsigned char IT3           : 1;
    unsigned char IT4           : 1;
    unsigned char IT5           : 1;
    unsigned char IT6           : 1;
    unsigned char               : 1;       /* Reserved; P6_7 is not available in DS4830A */
  } EIES6_bit;
} @ _M(1,16);

/* Port 6 Direction Register */
__no_init volatile __io union
{
  unsigned char PD6;
  struct
  {
    unsigned char PD6_0          : 1;
    unsigned char PD6_1          : 1;
    unsigned char PD6_2          : 1;
    unsigned char PD6_3          : 1;
    unsigned char PD6_4          : 1;
    unsigned char PD6_5          : 1;
    unsigned char PD6_6          : 1;
    unsigned char                : 1;       /* Reserved; P6_7 is not available in DS4830A */
  } PD6_bit;
} @ _M(1,17);

/* CRC8 output register */
__no_init volatile __io unsigned char CRC8OUT  @ _M(1,21);  /* */

/* ADC Scale Trim FS, Refer user guide for full scale value  */
__no_init volatile __io unsigned int ADCG1  @ _M(1,23);

/* ADC Scale Trim FS, Refer user guide for full scale value */
__no_init volatile __io unsigned int ADCG2  @ _M(1,24);

/* ADC Voltage Offset  */
//Note: ADVOFF is signed here.
__no_init volatile __io  signed int ADVOFF  @ _M(1,25);

/* ADC Scale Trim FS, Refer user guide for full scale value */
__no_init volatile __io unsigned int ADCG3  @ _M(1,27);

/* ADC Scale Trim FS, refer user guide for full scale value */
__no_init volatile __io unsigned int ADCG4  @ _M(1,28);

/* CHIP REVISION; Read only  */
__no_init volatile __io unsigned int CHIPREV  @ _M(1,29);

/* I2C SLAVE2 ADDRESS */
__no_init volatile __io union
{
  unsigned int I2CSLA2_M;
  struct
  {
    unsigned int I2CMODE         : 1;      /* I2C Master Read and Write mode       */
    unsigned int SLAVE_ADDRESS   : 7;      /* Address of Slave device (7 bit)      */
    unsigned int                 : 8;      /* Reserved                             */
  } I2CSLA2_M_bit;
} @ _M(1,30);

/*-----------------------------------------------------------------------*
 *                               Module 2                                *
 *-----------------------------------------------------------------------*/

//Note: I2CBUF_S is defined as unsigned int for faster code execution
/* I2C_S Data Buffer */
__no_init volatile __io unsigned int I2CBUF_S @ _M(2,0);

/* I2C_S Status Register */
__no_init volatile __io union
{
  unsigned int I2CST_S;
  struct
  {
    unsigned int I2CSRI         : 1;
    unsigned int I2CTXI         : 1;
    unsigned int I2CRXI         : 1;
    unsigned int I2CSTRI        : 1;
    unsigned int I2CTOI         : 1;
    unsigned int I2CAMI         : 1;
    unsigned int                : 1;
    unsigned int I2CNACKI       : 1;
    unsigned int I2CGCI         : 1;
    unsigned int I2CROI         : 1;
    unsigned int I2CSCL         : 1;
    unsigned int       		: 1;
    unsigned int                : 1;
    unsigned int 		: 1;
    unsigned int I2CBUSY        : 1;
    unsigned int I2CBUS         : 1;
  } I2CST_S_bit;
} @ _M(2,1);

/* Memory Address Pointer Register */
__no_init volatile __io union
{
  unsigned int MPNTR;
  struct
  {
    unsigned int MEM_PNTR       : 8;
    unsigned int PAGE           : 3;
    unsigned int                : 5;
  } MPNTR_bit;
} @ _M(2,2);

/* I2C Transmit Page Status Register  */
__no_init volatile __io union
{
  unsigned int I2CTXFST;
  struct
  {
    unsigned int             : 1;
    unsigned int THSH	     : 1;
    unsigned int             : 6;
    unsigned int             : 8;
  } I2CTXFST_bit;
} @ _M(2,3);


/* /* I2C Transmit Page Interrupt Enable Register */
__no_init volatile __io union
{
  unsigned int I2CTXFIE;
  struct
  {
    unsigned int             : 1;
    unsigned int THSH	     : 1;
    unsigned int             : 5;
    unsigned int TXPG_EN     : 1;
    unsigned int             : 8;
   } I2CTXFIE_bit;
} @ _M(2,4);


/* I2C Receive FIFO Status Register  */
__no_init volatile __io union
{
  unsigned int I2CRXFST;

   struct
   {
    unsigned int EMPTY       : 1;     /* RX FIFO EMPTY flag                  */
    unsigned int THSH        : 1;     /* RX THRESHOLD REACHED flag           */
    unsigned int             : 1;     /*                                     */
    unsigned int FULL        : 1;     /* RX FIFO FULL flag                   */
    unsigned int             : 1;
    unsigned int             : 3;
    unsigned int COUNT       : 4;     /* Future Use                          */
    unsigned int             : 4;
    } I2CRXFST_bit;
} @ _M(2,5);

/* I2C Receive FIFO Interrupt Enable Register  */
__no_init volatile __io union
{
  unsigned int I2CRXFIE;
  struct
  {
      unsigned int EMPTY       : 1;     /* RX FIFO EMPTY Enable               */
      unsigned int THSH        : 1;     /* RX THRESHOLD REACHED flag          */
      unsigned int             : 1;     /* RX ALMOST FULL Enable              */
      unsigned int FULL	       : 1;     /* RX FIFO FULL Enable                */
      unsigned int             : 1;
      unsigned int             : 2;
      unsigned int RXFIFO_EN         : 1;      //Reserved, Future Use
      unsigned int             : 8;
  } I2CRXFIE_bit;
} @ _M(2,6);


/* I2C_S Status Register */
__no_init volatile __io union
{
  unsigned int I2CST2_S;
  struct
  {
    unsigned int                : 1;
    unsigned int I2CXFRON       : 1;
    unsigned int IDLE_ST        : 1;      //Reserved, Future Use
    unsigned int MADI           : 1;
    unsigned int SADI           : 1;
    unsigned int I2CSPI         : 1;
    unsigned int                : 2;
    unsigned int                : 8;
  } I2CST2_S_bit;
} @ _M(2,7);

/* Read Pointer, Read only  */
__no_init volatile __io union
{
  unsigned int RPNTR;
  struct
  {
    unsigned int MEM_PNTR       : 8;
    unsigned int PAGE           : 3;
    unsigned int                : 5;
  } RPNTR_bit;
} @ _M(2,8);

/* I2C_S Control Register */
__no_init volatile __io union
{
  unsigned int I2CCN_S;
  struct
  {
    unsigned int I2CEN          : 1;       /* I2C Enable                          */
    unsigned int                : 1;       /* Reserved                            */
    unsigned int I2CMODE        : 1;       /* I2C MODE FOR ALL SLAVES             */
    unsigned int                : 1;       /* Reserved                            */
    unsigned int I2CSTRS        : 1;       /* I2C Clock Stretch Select            */
    unsigned int I2CACK         : 1;       /* I2C Data Acknowledge Bit            */
    unsigned int I2CSTART       : 1;       /* I2C START Enable                    */
    unsigned int I2CSTOP        : 1;       /* I2C STOP Enable                     */
    unsigned int I2CGCEN        : 1;       /* I2C General Call Enable             */
    unsigned int I2CSTREN       : 1;       /* I2C Clock Stretch Enable            */
    unsigned int SMB_MOD        : 1;       /* SMBus Timeout Enable                */
    unsigned int ADDR2EN	: 1;	   /* Slave Address 2 Enable              */
    unsigned int ADDR3EN	: 1;	   /* Slave Address 3 Enable              */
    unsigned int ADDR4EN	: 1;	   /* Slave Address 4 Enable              */
    unsigned int DISIDLE    	: 1;	   /* Resevered, Future use               */
    unsigned int               : 1;        /*                                     */
  } I2CCN_S_bit;
} @ _M(2,9);

/* I2C_S Slave Address Register */
__no_init volatile __io union
{
  unsigned int I2CSLA_S;
  struct
  {
    unsigned int I2CMODE         : 1;      /* Read and Write mode             */
    unsigned int SLAVE_ADDRESS   : 7;      /* Address of Slave device (7 bit) */
    unsigned int                 : 8;      /* Reserved*/
  } I2CSLA_S_bit;
} @ _M(2,12);

/* I2C_S Slave Address2 Register */
__no_init volatile __io union
{
  unsigned int I2CSLA2_S;
  struct
  {
    unsigned int I2CMODE         : 1;      /* Read and Write mode             */
    unsigned int SLAVE_ADDRESS   : 7;      /* Address of Slave device (7 bit) */
    unsigned int                 : 8;      /* Reserved*/
  } I2CSLA2_S_bit;
} @ _M(2,13);

/* I2C_S Slave Address3 Register */
__no_init volatile __io union
{
  unsigned int I2CSLA3_S;
  struct
  {
    unsigned int I2CMODE         : 1;      /* Read and Write mode             */
    unsigned int SLAVE_ADDRESS   : 7;      /* Address of Slave device (7 bit) */
    unsigned int                 : 8;      /* Reserved*/
  } I2CSLA3_S_bit;
} @ _M(2,14);

/* I2C_S Slave Address4 Register */
__no_init volatile __io union
{
  unsigned int I2CSLA4_S;
  struct
  {
    unsigned int I2CMODE         : 1;      /* I2C Master Read and Write mode  */
    unsigned int SLAVE_ADDRESS   : 7;      /* Address of Slave device (7 bit) */
    unsigned int                 : 8;      /* Reserved*/
  } I2CSLA4_S_bit;
} @ _M(2,15);

/* I2C_S Interrupt Enable2 Register */
__no_init volatile __io union
{
  unsigned int I2CIE2_S;
  struct
  {
    unsigned int                 : 1;
    unsigned int                 : 1;
    unsigned int                 : 1;
    unsigned int MADIE           : 1;
    unsigned int SADIE           : 1;
    unsigned int I2CSPIE         : 1;
    unsigned int                 : 2;
    unsigned int                 : 8;
  } I2CIE2_S_bit;
} @ _M(2,16);

/* Memory Address Pointer Register */
__no_init volatile __io union
{
  unsigned int MADDR;
  struct
  {
    unsigned int MEM_ADDR         : 8;
    unsigned int PAGE             : 3;
    unsigned int                  : 1;
    unsigned int ROLLOVR          : 1;         //0 - > 128 1 -> 256
    unsigned int                  : 3;
  } MADDR_bit;
} @ _M(2,17);

/* Memory Address Pointer2 Register */
__no_init volatile __io union
{
  unsigned int MADDR2;
  struct
  {
    unsigned int MEM_ADDR         : 8;
    unsigned int PAGE             : 3;
    unsigned int                  : 1;
    unsigned int ROLLOVR          : 1; //0 - > 128 1 -> 256
    unsigned int                  : 3;
  } MADDR2_bit;
} @ _M(2,18);

/* Memory Address Pointer3 Register */
__no_init volatile __io union
{
  unsigned int MADDR3;
  struct
  {
    unsigned int MEM_ADDR         : 8;
    unsigned int PAGE             : 3;
    unsigned int                  : 1;
    unsigned int ROLLOVR          : 1; //0 - > 128 1 -> 256
    unsigned int                  : 3;
  } MADDR3_bit;
} @ _M(2,19);

/* Memory Address Pointer4 Register */
__no_init volatile __io union
{
  unsigned int MADDR4;
  struct
  {
    unsigned int MEM_ADDR         : 8;
    unsigned int PAGE             : 3;
    unsigned int                  : 1;
    unsigned int ROLLOVR          : 1; //0 - > 128 1 -> 256
    unsigned int                  : 3;
  } MADDR4_bit;
} @ _M(2,20);

/* Current Active Slave Register */
__no_init volatile __io union
{
  unsigned int CUR_SLA;
  struct
  {
    unsigned int SLA1         : 1;
    unsigned int SLA2         : 1;
    unsigned int SLA3         : 1;
    unsigned int SLA4         : 1;
    unsigned int MADDR_EN1    : 1;
    unsigned int MADDR_EN2    : 1;
    unsigned int MADDR_EN3    : 1;
    unsigned int MADDR_EN4    : 1;
    unsigned int              : 8;
  } CUR_SLA_bit;
} @ _M(2,21);

/* I2C_S Interrupt Enable Register */
__no_init volatile __io union
{
  unsigned int I2CIE_S;
  struct
  {
    unsigned int I2CSRIE        : 1;
    unsigned int I2CTXIE        : 1;
    unsigned int I2CRXIE        : 1;
    unsigned int I2CSTRIE       : 1;
    unsigned int I2CTOIE        : 1;
    unsigned int I2CAMIE        : 1;
    unsigned int                : 1;
    unsigned int I2CNACKIE      : 1;
    unsigned int I2CGCIE        : 1;
    unsigned int I2CROIE        : 1;
    unsigned int                : 1;
    unsigned int                : 1;
    unsigned int                : 4;
  } I2CIE_S_bit;
} @ _M(2,22);

/* In-circuit Debug Temp 0 Register */
__no_init volatile __io unsigned int ICDT0 @ _M(2,24);

/* In-circuit Debug Temp 1 Register */
__no_init volatile __io unsigned int ICDT1  @ _M(2,25);

/* In-circuit Debug Control Register */
__no_init volatile __io union
{
  unsigned char ICDC;
  struct
  {
    unsigned char CMD          : 4;       /* Command Bits               */
    unsigned char              : 1;       /* Reserved                   */
    unsigned char REGE         : 1;       /* Break on Register Enable   */
    unsigned char              : 1;       /* Reserved                   */
    unsigned char DME          : 1;       /* Debug Mode Enable          */
  } ICDC_bit;
} @ _M(2,26);

/* ICD Flags */
__no_init volatile __io union
{
  unsigned char ICDF;
  struct
  {
    unsigned char TXC           : 1;      /* Serial Transfer Complete        */
    unsigned char JTAG_SPE      : 1;      /* System Program Enable           */
    unsigned char PSS           : 2;      /* Programming Source Select Bits  */
    unsigned char               : 4;      /* Reserved                        */
  } ICDF_bit;
} @ _M(2,27);

/* In-circuit Debug Buffer Register */
__no_init volatile __io unsigned char  ICDB @ _M(2,28);

/* In-circuit Debug Address Register */
__no_init volatile __io unsigned int ICDA  @ _M(2,29);

/* In-circuit Debug Data Register */
__no_init volatile __io unsigned int ICDD @ _M(2,30);

/*-----------------------------------------------------------------------*
 *                               Module 3                                *
 *----------------------------------------------------------------------*/

/* Multiplier Control Register */
__no_init volatile __io union
{
  unsigned char MCNT;
  struct
  {
    unsigned char SUS            : 1;		/* Signed-Unsigned               */
    unsigned char MMAC           : 1;		/* Multiply-Accumulate Enable    */
    unsigned char MSUB		 : 1;	        /* Multiply-Accumulate Negate    */
    unsigned char OPCS           : 1;		/* Operand Count Select          */
    unsigned char SQU            : 1;		/* Square Function Enable        */
    unsigned char CLD            : 1;		/* Clear Data register           */
    unsigned char MCW            : 1;		/* MC Register Write Select      */
    unsigned char OF             : 1;		/* Overflow Flag                 */
  } MCNT_bit;
} @ _M(3,0);

/* Multiplier Operand A Register    */
__no_init volatile __io unsigned int MA  @ _M(3,1);

/* Multiplier Operand B Register    */
__no_init volatile __io unsigned int MB  @ _M(3,2);

/* Multiplier Accumulate Register 2 */
__no_init volatile __io unsigned int MC2 @ _M(3,3);

/* Multiplier Accumulate Register 1 */
__no_init volatile __io unsigned int MC1 @ _M(3,4);

/* Multiplier Accumulate Register 0 */
__no_init volatile __io unsigned int MC0 @ _M(3,5);

/* General Timer2 Control Register */
__no_init volatile __io union
{
  unsigned int GTCN2;
  struct
  {
    unsigned int GTPS           : 3;   /* Timer Clock Prescaler          */
    unsigned int                : 1;   /* Reserved                       */
    unsigned int GTIF           : 1;   /* General Timer Interrupt flag   */
    unsigned int                : 3;   /* Reserved                       */
    unsigned int GTIE           : 1;   /* General Timer Interrupt Enable */
    unsigned int CLK_SEL        : 2;   /* General Timer Clock Select     */
    unsigned int MODE           : 1;   /* Timer Mode                     */
    unsigned int GTR            : 1;   /* Timer Run Control              */
    unsigned int                : 3;   /* Reserved                       */
  } GTCN2_bit;
} @ _M(3,6);

/* Multiplier Shift Register */
__no_init volatile __io union
{
  unsigned char SHFT;
  struct
  {
    unsigned char SL             : 1;   /* Shift Left of MC2-MC0 result   */
    unsigned char SR             : 1;   /* Shift Right of MC2-MC0 result  */
    unsigned char                : 5;
    unsigned char SHC            : 1;   /* Shift Carry                    */
  } SHFT_bit;
} @ _M(3,7);

/* Multiplier Read Register 1 */
__no_init volatile __io unsigned int MC1R @ _M(3,8);

/* Multiplier Read Register 0 */
__no_init volatile __io unsigned int MC0R @ _M(3,9);

/* General Timer2 Capture Register  */
__no_init volatile __io unsigned int GTC2  @ _M(3,10);

/* General Timer2 Value Register   */
__no_init volatile __io unsigned int GTV2  @ _M(3,11);

/* General Purpose SFR 1  */
__no_init volatile __io unsigned int GP_REG1  @ _M(3,12);

/* General Purpose SFR 2  */
__no_init volatile __io unsigned int GP_REG2  @ _M(3,13);

/* MAC Control Register  */
__no_init volatile __io union
{
  unsigned int MACSEL;          //Internal MAC_CTRL
  struct
  {
    unsigned int MACRSEL        : 1;   /* MAC0/1 Registers Select bit    */
    unsigned int                : 7;   /* Reserved                       */
    unsigned int                : 8;   /* Reserved                       */
  }MACSEL_bit;
} @ _M(3,14);

/* Softwar Interrupts and User Flags Register  */
__no_init volatile __io union
{
  unsigned int USER_INT;
  struct
  {
    unsigned int SW_INT0        : 1;   /* Software Interrupt 0           */
    unsigned int SW_INT1        : 1;   /* Software Interrupt 1           */
    unsigned int SW_INT2        : 1;   /* Software Interrupt 2           */
    unsigned int SW_INT3        : 1;   /* Software Interrupt 3           */
    unsigned int SW_F0          : 1;   /* Software Flag 0                */
    unsigned int SW_F1          : 1;   /* Software Flag 1                */
    unsigned int SW_F2          : 1;   /* Software Flag 2                */
    unsigned int SW_F3          : 1;   /* Software Flag 3                */
    unsigned int                : 8;   /* Reserved                       */
  }USER_INT_bit;
} @ _M(3,15);

/* General Purpose SFR 3  */
__no_init volatile __io unsigned int GP_REG3  @ _M(3,16);

/* General Purpose SFR 4  */
__no_init volatile __io unsigned int GP_REG4  @ _M(3,17);

/* General Purpose SFR 5  */
__no_init volatile __io unsigned int GP_REG5  @ _M(3,18);

/* General Purpose SFR 6  */
__no_init volatile __io unsigned int GP_REG6  @ _M(3,19);

/* General Purpose SFR 7  */
__no_init volatile __io unsigned int GP_REG7  @ _M(3,20);

/* General Purpose SFR 8  */
__no_init volatile __io unsigned int GP_REG8  @ _M(3,21);

/* General Purpose SFR 9  */
__no_init volatile __io unsigned int GP_REG9  @ _M(3,22);

/* General Purpose SFR 10  */
__no_init volatile __io unsigned int GP_REG10  @ _M(3,23);

/* General Purpose SFR 11  */
__no_init volatile __io unsigned int GP_REG11  @ _M(3,24);

/* General Purpose SFR 12  */
__no_init volatile __io unsigned int GP_REG12  @ _M(3,25);

/* General Purpose SFR 13  */
__no_init volatile __io unsigned int GP_REG13  @ _M(3,26);

/* General Purpose SFR 14  */
__no_init volatile __io unsigned int GP_REG14  @ _M(3,27);

/* General Purpose SFR 15  */
__no_init volatile __io unsigned int GP_REG15  @ _M(3,28);

/* General Purpose SFR 15  */
__no_init volatile __io unsigned int GP_REG16  @ _M(3,29);

/*-----------------------------------------------------------------------*
 *                               Module 4                                *
 *----------------------------------------------------------------------*/
/* ADC Control Register */
__no_init volatile __io union
{
  unsigned int ADCN;
  struct
  {
    unsigned int ADACQ          : 4;     /* ADC Acquistion Extension Bits         */
    unsigned int LOC_OVR        : 1;     /* Location Override Bit                 */
    unsigned int ADDAIE         : 1;     /* ADC Data Available Interrupt Enable   */
    unsigned int ADCONT         : 1;     /* ADC Continuous Sequence Mode          */
    unsigned int ADDAINV        : 1;     /* ADC Data Available Interrupt Interval */
    unsigned int NUM_SMP        : 5;     /* Number of Samples                     */
    unsigned int ADCCLK         : 3;     /* ADC Clock Divider                     */
  } ADCN_bit;
} @ _M(4,0);

/* Sample and Hold Internal Trigger Enable Register*/
__no_init volatile __io union
{
  unsigned int SENR;
  struct
  {
    unsigned int INT_TRIG0      : 1;     /* Sample & Hold 0 Internal Trigger Bit        */
    unsigned int INT_TRIG_EN0   : 1;     /* Sample & Hold 0 Internal Trigger Enable Bit */
    unsigned int                : 2;
    unsigned int INT_TRIG1      : 1;     /* Sample & Hold 1 Internal Trigger Bit        */
    unsigned int INT_TRIG_EN1   : 1;     /* Sample & Hold 1 Internal Trigger Enable Bit */
    unsigned int                : 2;     /* Reserved                                    */
    unsigned int                : 8;     /* Reserved                                    */
  } SENR_bit;
} @ _M(4,1);

/* ADC Status Register */
__no_init volatile __io union
{
  unsigned int ADST;
  struct
  {
    unsigned int ADIDX          : 5;     /* ADC Register Index Bits                        */
    unsigned int ADCFG          : 1;     /* ADC Conversion Configuration Register Select   */
    unsigned int ADCONV         : 1;     /* ADC Start Conversion                           */
    unsigned int ADCAVG         : 1;     /* ADC Average Configuration Register             */
    unsigned int                : 3;     /* Reserved                                       */
    unsigned int                : 1;     /* Enable 2X   Changed to ADCLK2X               */
    unsigned int                : 3;     /* Reserved                                       */
    unsigned int                : 1;     /* Disable Collision Control  (Internal Use Only  */
  } ADST_bit;
} @ _M(4,2);

/* ADC Status Register */
__no_init volatile __io union
{
  unsigned int ADST1;
  struct
  {
     unsigned int ADDAI          : 1;     /* ADC Data Available Interrupt Flag              */
     unsigned int INTDAI         : 1;     /* Internal Temperature Data Available Interrupt  */
     unsigned int                : 1;     /* Reserved                                       */
     unsigned int                : 1;     /* Reserved                                       */
     unsigned int SH0DAI         : 1;     /* Sample & Hold 0 Data Available Interrupt       */
     unsigned int SH1DAI         : 1;     /* Sample & Hold 1 Data Available Interrupt       */
     unsigned int                : 2;     /* Reserved                                       */
     unsigned int                : 8;     /* Reserved                                       */
  } ADST1_bit;
} @ _M(4,3);

/* ADC Data Register */
__no_init volatile __io union
{
  //Note: ADDATA is signed here
  signed int ADDATA;
  struct
  {
    unsigned int ADCH           : 5;     /* ADC Channel Select                       */
    unsigned int ADDIFF         : 1;     /* ADC Differential Mode Select             */
    unsigned int ADALIGN        : 1;     /* ADC Data Alignment Select                */
    unsigned int ADACQEN        : 1;     /* ADC Acquistion  Extension Enable         */
    unsigned int ALT_LOC        : 5;     /* Alternate location for conversion result */
    unsigned int ADGAIN         : 2;     /* ADC Reference Select                     */
    unsigned int                : 1;     /* Reserved                                 */
  } ADDATA_bit;
} @ _M(4,4);

/* SPI Slave Data Buffer */
__no_init volatile __io unsigned int SPIB_S @ _M(4,5);

__no_init volatile __io union
{
  unsigned int DADDR;
  struct
  {
     unsigned int DATA           : 8;    /* Data Field                             */
     unsigned int RWN       	 : 1;    /* Read/Write Select Bit                  */
     unsigned int ADDR           : 7;    /* Address Field                          */
  } DADDR_bit;
} @ _M(4,6);

__no_init volatile __io union
{
  unsigned int MIIR4;
  struct
  {
     unsigned int ADC            : 1;    /* ADC Module Interrupt Flag               */
     unsigned int TW       	 : 1;    /* 3-Wire Module Interrupt Flag            */
     unsigned int SPI_S          : 1;    /* SPI Slave Module Interrupt Flag         */
     unsigned int                : 5;    /* Reserved                                */
     unsigned int                : 8;    /* Reserved                                */
  } MIIR4_bit;
} @ _M(4,7);

/* Temperature Control Register */
__no_init volatile __io union
{
  unsigned int TEMPCN;
  struct
  {
    unsigned int INT_TEMP       : 1;     /* Internal Temperature Enable                 */
    unsigned int                : 1;     /* Reserved                                    */
    unsigned int                : 1;     /* Reserved                                    */
    unsigned int                : 1;     /* Reserved                                    */
    unsigned int INT_ALIGN      : 1;     /* Internal Temperature Data Align             */
    unsigned int                : 1;     /* Reserved                                    */
    unsigned int                : 1;     /* Reserved                                    */
    unsigned int                : 1;     /* Reserved                                    */
    unsigned int                : 1;     /* Reserved                                    */
    unsigned int                : 1;     /* Reserved                                    */
    unsigned int INT_IEN        : 1;     /* Internal Temperature Interrupt Enable       */
    unsigned int                : 5;     /* Reserved                                    */
  } TEMPCN_bit;
} @ _M(4,8);

/* Sample and Hold Control Register */
__no_init volatile __io union
{
  unsigned int SHCN;
  struct
  {
    unsigned int SMP_HLD0       : 1;     /* Sample & Hold0 Enable           */
    unsigned int SHDAI0_EN      : 1;     /* Sample & Hold0 Interrupt Enable */
    unsigned int SH0_ALGN       : 1;     /* Sample & Hold0 Data Align       */
    unsigned int CLK_SEL        : 1;     /* Clock Select for SHEN           */
    unsigned int SMP_HLD1       : 1;     /* Sample & Hold1 Enable           */
    unsigned int SHDAI1_EN      : 1;     /* Sample & Hold1 Interrupt Enable */
    unsigned int SH1_ALGN       : 1;     /* Sample & Hold1 Data Align       */
    unsigned int                : 1;     /* Reserved                        */
    unsigned int SH_DUAL        : 1;     /* Sample & Hold Dual Mode         */
    unsigned int PIN_DIS0       : 1;     /* Pin Disshortge Enable 0         */
    unsigned int PIN_DIS1       : 1;     /* Pin Disshortge Enable 1         */
    unsigned int FAST_MODE      : 1;     /* Fast Mode Enable                */
    unsigned int SSC            : 4;     /* Stop Sample Control             */
  } SHCN_bit;
} @ _M(4,9);

/* ADC Pin Select Register */
__no_init volatile __io union
{
  unsigned int PINSEL;
  struct
  {
    unsigned int PINSEL0        : 1;
    unsigned int PINSEL1        : 1;
    unsigned int PINSEL2        : 1;
    unsigned int PINSEL3        : 1;
    unsigned int PINSEL4        : 1;
    unsigned int PINSEL5        : 1;
    unsigned int PINSEL6        : 1;
    unsigned int PINSEL7        : 1;
    unsigned int PINSEL8        : 1;
    unsigned int PINSEL9        : 1;
    unsigned int PINSEL10       : 1;
    unsigned int PINSEL11       : 1;
    unsigned int PINSEL12       : 1;
    unsigned int PINSEL13       : 1;
    unsigned int PINSEL14       : 1;
    unsigned int PINSEL15       : 1;
  } PINSEL_bit;
} @ _M(4,11);

/* ADC Average and ADC Reference Control Register */
__no_init volatile __io union
{
  unsigned int REFAVG;
  struct
  {
    unsigned int SH0AVG         : 2;     /* S/H0 Averaging configuration Bits             */
    unsigned int SH1AVG         : 2;     /* S/H1 Averaging configuration Bits             */
    unsigned int INTAVG         : 2;     /* Internal Die Temp Averaging configuration Bits*/
    unsigned int                : 2;     /* Reserved                                      */
    unsigned int INTREF         : 1;     /* Internal Reference ON/OFF Control bit         */
    unsigned int REFOUT         : 1;     /* Internal Reference Out at GP1 Pin Control bit */
    unsigned int                : 1;     /*                                               */
    unsigned int                : 5;     /*                                               */
  } REFAVG_bit;
} @ _M(4,12);

/* Three Wire Control Register */
__no_init volatile __io union
{
  unsigned char TWR;
  struct
  {
    unsigned char BUSY           : 1;     /* 3 Wire Busy Flag             */
    unsigned char TWI            : 1;     /* 3 Wire Interrupt Flag        */
    unsigned char TWCSDIS        : 1;     /* 3 Wire Chip Select Flag      */
    unsigned char TWIE           : 1;     /* 3 Wire Interrupt Enable Flag */
    unsigned char TWCP           : 3;     /* 3 Wire Clock Period          */
    unsigned char TWEN           : 1;     /* 3 Wire Enable                */
  } TWR_bit;
} @ _M(4,14);


/* DAC Reference Measurement @ADC Config Register */
__no_init volatile __io union
{
  unsigned int RPCFG;                       //Internal RCFG
  struct
  {
    unsigned int REFA_CFG          : 1;     /*  REFINA ADC MEASUREMENT -WO DAC0-3 ENABLE    */
    unsigned int REFB_CFG          : 1;     /*  REFINB ADC MEASUREMENT -WO DAC4-7 ENABLE    */
    unsigned int                   : 6;     /*                                              */
    unsigned int                   : 8;     /*                                              */
  } RPCFG_bit;
} @ _M(4,15);

/* SPI Slave Control Register */
__no_init volatile __io union
{
  unsigned char SPICN_S;
  struct
  {
    unsigned char SPIEN          : 1;     /* SPI Enable                 */
    unsigned char MSTM           : 1;     /* SPI Master Mode Enable     */
    unsigned char MODFE          : 1;     /* Mode Fault Enable          */
    unsigned char MODF           : 1;     /* Mode Fault Flag            */
    unsigned char WCOL           : 1;     /* Write Collision Flag       */
    unsigned char ROVR           : 1;     /* Receive Overrun Flag       */
    unsigned char SPIC           : 1;     /* SPI Transfer Complete Flag */
    unsigned char STBY           : 1;     /* SPI Transfer Busy Flag     */
  } SPICN_S_bit;
} @ _M(4,16);

/* SPI Configuration Register */
__no_init volatile __io union
{
  unsigned char SPICF_S;
  struct
  {
    unsigned char CKPOL          : 1;     /* Clock Polarity Select            */
    unsigned char CKPHA          : 1;     /* Clock Phase Select               */
    unsigned char CHR            : 1;     /* Character Bit Length (8/16 Bits) */
    unsigned char                : 3;     /* Reserved                         */
    unsigned char SAS            : 1;     /* Slave Chip Select Config         */
    unsigned char ESPII          : 1;     /* SPI Interrupt Enable             */
  } SPICF_S_bit;
} @ _M(4,17);

/* SPI Clock Register */
__no_init volatile __io unsigned char SPICK_S @ _M(4,18);

/* I2C Bootload Enable Register. Only I2C_SPB.0:I2C_SPE is usable */
__no_init volatile __io unsigned char  I2C_SPB  @ _M(4,19);

/* Device Number and Bootloader Disable*/
__no_init volatile __io union
{
  unsigned char DEV_NUM;
  struct
  {
    unsigned char DEVNUM         : 7;     /* Device Number                    */
    unsigned char DIS_BOOT_ADDR  : 1;     /* Bootloader Address (34h) Disable)*/
  }DEV_NUM_bit;
} @ _M(4,20);

/* DAC Data Registers 0-7 */
__no_init volatile __io unsigned int DACD0  @ _M(4,21);   /* DAC Channel 0 Data Register */

__no_init volatile __io unsigned int DACD1  @ _M(4,22);   /* DAC Channel 1 Data Register */

__no_init volatile __io unsigned int DACD2  @ _M(4,23);   /* DAC Channel 2 Data Register */

__no_init volatile __io unsigned int DACD3  @ _M(4,24);   /* DAC Channel 3 Data Register */

__no_init volatile __io unsigned int DACD4  @ _M(4,25);   /* DAC Channel 4 Data Register */

__no_init volatile __io unsigned int DACD5  @ _M(4,26);   /* DAC Channel 5 Data Register */

__no_init volatile __io unsigned int DACD6  @ _M(4,27);   /* DAC Channel 6 Data Register */

__no_init volatile __io unsigned int DACD7  @ _M(4,28);   /* DAC Channel 7 Data Register */

/* DAC Configuration Register*/
__no_init volatile __io union
{
  unsigned int DACCFG;
  struct
  {
    unsigned int DACCFG0        : 2;       /* DAC Ch0 Enable/Reference select */
    unsigned int DACCFG1        : 2;       /* DAC Ch1 Enable/Reference select */
    unsigned int DACCFG2        : 2;       /* DAC Ch2 Enable/Reference select */
    unsigned int DACCFG3        : 2;       /* DAC Ch3 Enable/Reference select */
    unsigned int DACCFG4        : 2;       /* DAC Ch4 Enable/Reference select */
    unsigned int DACCFG5        : 2;       /* DAC Ch5 Enable/Reference select */
    unsigned int DACCFG6        : 2;       /* DAC Ch6 Enable/Reference select */
    unsigned int DACCFG7        : 2;       /* DAC Ch7 Enable/Reference select */
  } DACCFG_bit;
} @ _M(4,29);

/* ADC Address Register */
__no_init volatile __io union
{
  unsigned int ADADDR;
  struct
  {
    unsigned int ADEND          : 5;     /* ADC Conversion Configuraiton End Address   */
    unsigned int                : 3;     /* Reserved                                   */
    unsigned int ADSTART        : 5;     /* ADC Conversion Configuraiton Start Address */
    unsigned int                : 3;     /* Reserved                                   */
  } ADADDR_bit;
} @ _M(4,30);

/*-----------------------------------------------------------------------*
 *                               Module 5                                *
 *----------------------------------------------------------------------*/

/* Quick Trip Data Register */
__no_init volatile __io unsigned int QTDATA  @ _M(5,0);

/* Quick Trip Control Register*/
__no_init volatile __io union
{
  unsigned int QTCN;
  struct
  {
    unsigned int QTIDX          : 4;     /* Quick Trip Channel Select              */
    unsigned int LTHT           : 1;     /* Quick Trip Threshold Select (High/Low) */
    unsigned int                : 2;     /* Reserved                               */
    unsigned int RW_LST         : 1;     /* Quick Trip List Select                 */
    unsigned int                : 4;     /* Reserved                               */
    unsigned int QTEN           : 1;     /* Quick Trip Enable                      */
    unsigned int                : 3;     /* Reserved                               */
  } QTCN_bit;
} @ _M(5,1);

/* Low Trip Interrupt Flag Register */
__no_init volatile __io union
{
  unsigned int LTIL;
  struct
  {
    unsigned int IF0            : 1;
    unsigned int IF1            : 1;
    unsigned int IF2            : 1;
    unsigned int IF3            : 1;
    unsigned int IF4            : 1;
    unsigned int IF5            : 1;
    unsigned int IF6            : 1;
    unsigned int IF7            : 1;
    unsigned int IE0            : 1;
    unsigned int IE1            : 1;
    unsigned int IE2            : 1;
    unsigned int IE3            : 1;
    unsigned int IE4            : 1;
    unsigned int IE5            : 1;
    unsigned int IE6            : 1;
    unsigned int IE7            : 1;
  } LTIL_bit;
} @ _M(5,2);

/* High Trip Interrupt Flag Register */
__no_init volatile __io union
{
  unsigned int HTIL;
  struct
  {
    unsigned int IF0            : 1;
    unsigned int IF1            : 1;
    unsigned int IF2            : 1;
    unsigned int IF3            : 1;
    unsigned int IF4            : 1;
    unsigned int IF5            : 1;
    unsigned int IF6            : 1;
    unsigned int IF7            : 1;
    unsigned int IE0            : 1;
    unsigned int IE1            : 1;
    unsigned int IE2            : 1;
    unsigned int IE3            : 1;
    unsigned int IE4            : 1;
    unsigned int IE5            : 1;
    unsigned int IE6            : 1;
    unsigned int IE7            : 1;
  } HTIL_bit;
} @ _M(5,3);

/* SPI Master Data Buffer */
__no_init volatile __io unsigned int SPIB_M  @ _M(5,4);

/* PWM Data Register */
__no_init volatile __io unsigned int PWMDATA  @ _M(5,5);

/* PWM Control Register */
__no_init volatile __io union
{
  unsigned int PWMCN;
  struct
  {
    unsigned int REG_SEL        : 2;     /* Register Select                        */
    unsigned int                : 2;     /* Reserved                               */
    unsigned int PWM_SEL        : 4;     /* PWM Channel Select                     */
    unsigned int UPDATE         : 1;     /* Update Set Duty Cycle                  */
    unsigned int                : 3;     /* Reserved                               */
    unsigned int M_EN           : 1;     /* Master Enable (All PWN Channel Enable) */
    unsigned int                : 3;     /* Reserved                               */
  } PWMCN_bit;
} @ _M(5,6);

/* PWM Synchroniation Register   */
__no_init volatile __io unsigned int PWMSYNC  @ _M(5,7);

/* Low Trip Interrupt Enable Register */
__no_init volatile __io union
{
  unsigned int LTIH;            //Internal LTIE
  struct
  {
    unsigned int IF8            : 1;
    unsigned int IF9            : 1;
    unsigned int IF10           : 1;
    unsigned int IF11           : 1;
    unsigned int IF12           : 1;
    unsigned int IF13           : 1;
    unsigned int IF14           : 1;
    unsigned int IF15           : 1;
    unsigned int IE8            : 1;
    unsigned int IE9            : 1;
    unsigned int IE10           : 1;
    unsigned int IE11           : 1;
    unsigned int IE12           : 1;
    unsigned int IE13           : 1;
    unsigned int IE14           : 1;
    unsigned int IE15           : 1;
  } LTIH_bit;
} @ _M(5,8);

/* High Trip Interrupt Enable Register */
__no_init volatile __io union
{
  unsigned int HTIH;                    //Internal HTIE
  struct
  {
    unsigned int IF8            : 1;
    unsigned int IF9            : 1;
    unsigned int IF10           : 1;
    unsigned int IF11           : 1;
    unsigned int IF12           : 1;
    unsigned int IF13           : 1;
    unsigned int IF14           : 1;
    unsigned int IF15           : 1;
    unsigned int IE8            : 1;
    unsigned int IE9            : 1;
    unsigned int IE10           : 1;
    unsigned int IE11           : 1;
    unsigned int IE12           : 1;
    unsigned int IE13           : 1;
    unsigned int IE14           : 1;
    unsigned int IE15           : 1;
  } HTIH_bit;
} @ _M(5,9);

/* QTLST Control Register*/
__no_init volatile __io union
{
  unsigned int QTLST;
  struct
  {
    unsigned int QTEND          : 4;       /* Quick Trip Configuraiton End Address     */
    unsigned int QTSTART        : 4;       /* Quick Trip Configuraiton Start Address   */
    unsigned int                : 8;       /* Reserved                                 */
  } QTLST_bit;
} @ _M(5,10);

/* Module5 Interrupt Register */
__no_init volatile __io union
{
  unsigned int MIIR5;
  struct
  {
     unsigned int SPI_M       : 1;    /* SPI Master Module Interrupt            */
     unsigned int QT          : 1;    /* Quick Trip Module Interrupt            */
     unsigned int             : 1;    /*                                        */
     unsigned int             : 5;    /* Reserved                               */
     unsigned int             : 8;    /* Reserved                               */
  } MIIR5_bit;
} @ _M(5,14);

/* SPI Control Register */
__no_init volatile __io union
{
  unsigned char SPICN_M;
  struct
  {
    unsigned char SPIEN          : 1;     /* SPI Enable                 */
    unsigned char MSTM           : 1;     /* SPI Master Mode Enable     */
    unsigned char MODFE          : 1;     /* Mode Fault Enable          */
    unsigned char MODF           : 1;     /* Mode Fault Flag            */
    unsigned char WCOL           : 1;     /* Write Collision Flag       */
    unsigned char ROVR           : 1;     /* Receive Overrun Flag       */
    unsigned char SPIC           : 1;     /* SPI Transfer Complete Flag */
    unsigned char STBY           : 1;     /* SPI Transfer Busy Flag     */
  } SPICN_M_bit;
} @ _M(5,18);

/* SPI Configuration Register */
__no_init volatile __io union
{
  unsigned char SPICF_M;
  struct
  {
    unsigned char CKPOL          : 1;     /* Clock Polarity Select            */
    unsigned char CKPHA          : 1;     /* Clock Phase Select               */
    unsigned char CHR            : 1;     /* Character Bit Length (8/16 Bits) */
    unsigned char                : 3;     /* Reserved                         */
    unsigned char SAS            : 1;     /* Slave Chip Select Config         */
    unsigned char ESPII          : 1;     /* SPI Interrupt Enable             */
  } SPICF_M_bit;
} @ _M(5,19);

/* SPI Clock Register */
__no_init volatile __io unsigned char SPICK_M @ _M(5,20);

 /*-----------------------------------------------------------------------*
  *                               Module 8                                *
  *-----------------------------------------------------------------------*/

/* Only WDCN are defined in this file, the rest of the */
/* registers in Module 8 can be found in iomaxq.h.              */

/* Watchdog Control register */
__no_init volatile __io union
{
  unsigned char WDCN;
  struct
  {
    unsigned char RWT            : 1;     /* Reset Watchdog Timer             */
    unsigned char EWT            : 1;     /* Enable Watchdog Timer Reset      */
    unsigned char WTRF           : 1;     /* Watchdog Timer Reset Flag        */
    unsigned char WDIF           : 1;     /* Watchdog Interrupt Flag          */
    unsigned char WD0            : 1;     /* Watchdog Timer Mode Select Bit 0 */
    unsigned char WD1            : 1;     /* Watchdog Timer Mode Select Bit 1 */
    unsigned char EWDI           : 1;     /* Watchdog Interrupt Enable        */
    unsigned char POR            : 1;     /* Power-On Reset Flag              */
  } WDCN_bit;
} @ _M(8,15);

#pragma language=default
#endif  /* __IAR_SYSTEMS_ICC__  */
#endif /* __IODS4830A */
//End
